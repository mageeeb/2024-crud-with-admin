<?php
// chargement de configuration
require_once "config.php";

/*
 * Connexion à la base de données en utilisant PDO
 * Avec un try catch pour gérer les erreurs de connexion
 */
try {
    // création d'une instance de PDO - Connexion à la base de données
    $db = new PDO(DB_DRIVER . ":host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET . ";port=" . DB_PORT, DB_LOGIN, DB_PWD);
} catch (Exception $e) {
    die($e->getMessage());
}

$items = getAllData($db);

echo $items;

// fermeture de la connexion
$db = null;


/**
 * @param PDO $db
 * @return array
 * Fonction qui récupère le nombre d'items' venant de la base de données 'geo'
 */
function getNumber(PDO $db): string
{
    $sql = "SELECT COUNT(id) AS nb FROM theatres";
    $query = $db->query($sql);
    $result = $query->fetch(PDO::FETCH_ASSOC);
    $query->closeCursor();
    return json_encode($result);
}
 
/**
 * @param PDO $db
 * @return array
 * Fonction qui récupère toutes les données venant de la base de données 'geo'
 */
function getAllData(PDO $db): string
{
    $sql = "SELECT * FROM theatres ORDER BY id ASC";
    $query = $db->query($sql);
    $result = $query->fetchAll(PDO::FETCH_ASSOC);
    $query->closeCursor();
    return json_encode($result);
}
