<?php

// paramètres de connexions
const DB_DRIVER = "mysql";
const DB_HOST = "localhost";
const DB_LOGIN = "root";
const DB_PWD = "";
const DB_NAME = "geo";
const DB_PORT = 3306;
const DB_CHARSET = "utf8mb4";